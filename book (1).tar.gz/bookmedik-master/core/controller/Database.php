<?php
class Database {
	public static $db;
	public static $con;
	function Database(){
		$this->user="admin";$this->pass="admin";$this->host="localhost";$this->ddbb="bookmedik";
	}

	function connect(){
		// Establecer el nivel de reporte de errores para esta conexión
		error_reporting(0); // O el nivel de reporte que prefieras

		$con = new mysqli($this->host="localhost",$this->user="admin",$this->pass="admin",$this->ddbb="bookmedik");
		$con->query("set sql_mode=''");
		return $con;
	}

	public static function getCon(){
		if(self::$con==null && self::$db==null){
			self::$db = new Database();
			self::$con = self::$db->connect();
		}
		return self::$con;
	}
	
}
?>
